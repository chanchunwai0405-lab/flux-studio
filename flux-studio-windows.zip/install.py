"""Install the Windows GPU workbench into runtime/ beside this script."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
RUNTIME = ROOT / "runtime"
MODELS = json.loads((ROOT / "models.json").read_text())
PROJECTS = [
    ("ComfyUI-source", "https://github.com/Comfy-Org/ComfyUI.git", "989d93d0d968e704c589ce0146bb18c77f6b50cc", "venv"),
    ("SeedVR2-test", "https://github.com/numz/ComfyUI-SeedVR2_VideoUpscaler.git", "4490bd1f482e026674543386bb2a4d176da245b9", "seedvr-venv"),
]


def run(*args, cwd=None):
    subprocess.run([str(a) for a in args], cwd=cwd, check=True)


def verify(path, digest):
    if not path.is_file():
        return False
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest() == digest


def install_project(name, url, commit, env):
    source = RUNTIME / name
    if not (source / ".git").is_dir():
        run("git", "clone", "--no-checkout", url, source)
    run("git", "checkout", "--detach", commit, cwd=source)
    python = RUNTIME / env / "Scripts/python.exe"
    if not python.exists():
        run(sys.executable, "-m", "venv", RUNTIME / env)
    run(python, "-m", "pip", "install", "--index-url", "https://download.pytorch.org/whl/cu128",
        "torch==2.11.0", "torchvision==0.26.0", "torchaudio==2.11.0")
    run(python, "-m", "pip", "install", "-r", source / "requirements.txt",
        "-c", ROOT / (env + "-constraints.txt"), "huggingface-hub")
    run(python, "-c", "import torch; assert torch.cuda.is_available(), 'CUDA unavailable'")
    if env == "seedvr-venv":
        run(python, source / "inference_cli.py", "--help", cwd=source)


def install_models(old_root):
    for model in MODELS:
        target = RUNTIME / model["path"]
        target.parent.mkdir(parents=True, exist_ok=True)
        if verify(target, model["sha256"]):
            continue
        if old_root:
            src = old_root / model["old"]
            if not verify(src, model["sha256"]):
                raise SystemExit(f"Missing or incorrect model: {src}")
            temp = target.with_suffix(".partial")
            shutil.copyfile(src, temp)
        else:
            from huggingface_hub import hf_hub_download
            temp = Path(hf_hub_download(model["repo"], model["file"]))
        if not verify(temp, model["sha256"]):
            raise SystemExit(f"Model checksum mismatch: {target.name}")
        if old_root:
            temp.replace(target)
        else:
            shutil.copyfile(temp, target)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--models-from", type=Path, help="Original AI root, e.g. X:/AI")
    parser.add_argument("--models-only", action="store_true", help=argparse.SUPPRESS)
    options = parser.parse_args()
    if sys.version_info[:2] != (3, 12) or os.name != "nt":
        sys.exit("Use Windows x64 and Python 3.12.")
    for folder in ("tmp", "cache/huggingface", "cache/pip"):
        (RUNTIME / folder).mkdir(parents=True, exist_ok=True)
    os.environ.update(PYTHONUTF8="1", HF_HOME=str(RUNTIME/"cache/huggingface"),
                      PIP_CACHE_DIR=str(RUNTIME/"cache/pip"), TEMP=str(RUNTIME/"tmp"), TMP=str(RUNTIME/"tmp"))
    if options.models_only:
        install_models(options.models_from)
    else:
        for project in PROJECTS:
            install_project(*project)
        run(RUNTIME/"venv/Scripts/python.exe", __file__, "--models-only",
            *(["--models-from", options.models_from] if options.models_from else []))
        print("Ready. Run Start.cmd")
