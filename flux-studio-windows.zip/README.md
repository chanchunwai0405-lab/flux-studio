# FLUX 电商影像工作台

Windows 本地运行，支持文生图、参考图编辑、蒙版局部修改、加噪重绘及 SeedVR2 3K/4K 放大。手机可通过同一局域网访问。运算在启动工作台的 NVIDIA 电脑上进行。

## 在新电脑安装

1. 安装 Git for Windows、64 位 Python 3.12（含 py 启动器）及支持 CUDA 12.8 的 NVIDIA 驱动。本机参考配置为 RTX 4080 Laptop 12 GB、32 GB 内存。准备足够空间存放两套 Python 环境、模型和下载缓存。
2. 将仓库克隆或解压到有足够空间的目录，例如 E:\flux-studio。安装路径可变。安装前确保能访问 GitHub、PyPI、PyTorch 和 Hugging Face。
3. 若带有旧电脑模型，在仓库目录打开命令提示符运行 **Install.cmd --models-from X:\AI**（X:\AI 是旧模型备份的根目录）。只需按 models.json 中的 old 字段保留五个文件的相对路径。
4. 若在线下载，先用自己的 Hugging Face 账号取得 black-forest-labs/flux-3-image-klein-comfy 的访问权。按 Hugging Face 的登录流程配置凭据或在安装终端设置临时 HF_TOKEN，然后运行 **Install.cmd**。安装器会按固定提交安装 ComfyUI 和 SeedVR2、建立 CUDA 环境并核对模型 SHA256。中断后可重新执行。
5. 双击 **Start.cmd**。本机入口为 http://127.0.0.1:8189 。局域网设备打开 WebUI/ACCESS.txt 中当前的 LAN 地址。仅在可信局域网使用，工作台没有登录认证。需要放行 Windows 入站连接时，以管理员身份运行 WebUI/Enable-LAN.ps1。

工作台上传和生成记录位于 WebUI/jobs。需要迁移历史时，关闭服务后将旧电脑的 E:\AI\WebUI\jobs 复制到此目录。接口沿用 POST /api/jobs（表单）、GET /api/jobs/{id} 和 GET /api/result/{id}。workflows/ 提供可导入 ComfyUI 的工作流和 API JSON；工作台会按任务动态构建执行图。

首次使用可先提交 1024 文生图，再用生成结果测试放大。部署依赖的软件和模型遵循各自上游许可。
