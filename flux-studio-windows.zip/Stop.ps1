$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
foreach ($port in 8189,8188) {
    $listeners = Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue
    foreach ($owner in @($listeners.OwningProcess | Select-Object -Unique)) {
        if (!$owner) { continue }
        $proc = Get-CimInstance Win32_Process -Filter "ProcessId = $owner"
        if (!$proc) { continue }
        $parent = Get-CimInstance Win32_Process -Filter "ProcessId = $($proc.ParentProcessId)"
        $python = Join-Path $root 'runtime\venv\Scripts\python.exe'
        if ($parent.ExecutablePath -eq $python -or $proc.ExecutablePath -eq $python) {
            Stop-Process -Id $owner
        }
    }
}
