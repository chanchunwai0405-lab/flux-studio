$ErrorActionPreference = 'Stop'
try {
    if (-not (Get-NetFirewallRule -DisplayName 'FLUX Studio LAN 8189' -ErrorAction SilentlyContinue)) {
        New-NetFirewallRule -DisplayName 'FLUX Studio LAN 8189' -Direction Inbound -Action Allow -Protocol TCP -LocalPort 8189 -RemoteAddress LocalSubnet -InterfaceType Wired,Wireless -Profile Any | Out-Null
    }
    Get-NetFirewallRule -DisplayName 'FLUX Studio LAN 8189' | Select-Object DisplayName,Enabled | Out-File "$PSScriptRoot\firewall-result.txt"
} catch { $_ | Out-File "$PSScriptRoot\firewall-result.txt"; exit 1 }

