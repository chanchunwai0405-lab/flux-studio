import asyncio, copy, io, json, secrets, time, os, subprocess
from pathlib import Path
from aiohttp import web, ClientSession, WSMsgType
from PIL import Image, ImageOps, ImageFilter
import numpy as np

ROOT=Path(__file__).resolve().parent
INSTALL=ROOT.parent
COMFY=INSTALL/'runtime/ComfyUI-source'
DATA=ROOT/'jobs'; DATA.mkdir(exist_ok=True)
BASE=json.loads((INSTALL/'workflows/FLUX3_ecommerce_1024_api.json').read_text())
JOBS={}; LOCK=asyncio.Lock()
for saved in DATA.glob('*/status.json'):
    try:
        j=json.loads(saved.read_text(encoding='utf8')); JOBS[j['id']]=j
    except (ValueError,KeyError): pass

async def seedvr_upscale(j, source, seed, fit, target):
    folder=DATA/j['id']
    if fit=='crop': source=ImageOps.fit(source,(min(source.size),)*2,Image.Resampling.LANCZOS)
    source.save(folder/'upscale_input.png')
    model='seedvr2_ema_3b-Q8_0.gguf'
    j.update(status='正在放大',upscale_model='SeedVR2 3B Q8',fit=fit,stage='等待显卡空闲',progress_value=0,progress_max=0)
    async with ClientSession(trust_env=False) as session:
        while True:
            async with session.get('http://127.0.0.1:8188/queue') as response:
                response.raise_for_status(); queue=await response.json()
            if not queue.get('queue_running') and not queue.get('queue_pending'): break
            await asyncio.sleep(2)
        j['stage']='释放生成模型显存'
        async with session.post('http://127.0.0.1:8188/free',json={'unload_models':True,'free_memory':True}) as response: response.raise_for_status()
    await asyncio.sleep(3)
    args=[str(INSTALL/'runtime/seedvr-venv/Scripts/python.exe'),'-u',str(INSTALL/'runtime/SeedVR2-test/inference_cli.py'),str(folder/'upscale_input.png'),'--output',str(folder/'seedvr.png'),'--output_format','png','--model_dir',str(INSTALL/'runtime/SeedVR2-test/models'),'--dit_model',model,'--resolution',str(target),'--max_resolution',str(target),'--batch_size','1','--seed',str(seed),'--dit_offload_device','cpu','--vae_offload_device','cpu','--tensor_offload_device','cpu','--blocks_to_swap','32','--swap_io_components','--vae_encode_tiled','--vae_encode_tile_size','512','--vae_decode_tiled','--vae_decode_tile_size','512','--attention_mode','sdpa']
    (folder/'upscale_command.json').write_text(json.dumps(args,ensure_ascii=False,indent=2),encoding='utf8')
    env=os.environ.copy();env.update(PYTHONUTF8='1',HF_HOME=str(INSTALL/'runtime/cache/huggingface'),TEMP=str(INSTALL/'runtime/tmp'),TMP=str(INSTALL/'runtime/tmp'))
    split_first=512<=min(source.size) and max(source.size)<=1024
    if not split_first:
        try:
            return await seedvr_pass(folder,j,args,env,'')
        except MemoryError:
            if min(source.size)<2: raise
    # Split along the long axis and reconstruct both strips at the original target scale.
    rotated=source.height>source.width
    canvas=source.transpose(Image.Transpose.TRANSPOSE) if rotated else source
    w,h=canvas.size
    middle=w//2
    overlap=min(max(1,w//32),middle)
    height=max(1,round(target*h/w))
    merged=Image.new('RGB',(target,height))
    first_end=round((middle+overlap)*target/w)
    for i,(left,right) in enumerate(((0,middle+overlap),(middle-overlap,w))):
        x0=round(left*target/w)
        x1=round(right*target/w)
        part=canvas.crop((left,0,right,h))
        if rotated:part=part.transpose(Image.Transpose.TRANSPOSE)
        input_file=folder/f'strip{i}.png'
        part.save(input_file)
        cmd=args.copy()
        cmd[3]=str(input_file)
        cmd[cmd.index('--output')+1]=str(folder/f'strip{i}_out.png')
        cmd[cmd.index('--resolution')+1]=str(min(x1-x0,height))
        cmd[cmd.index('--max_resolution')+1]=str(max(x1-x0,height))
        piece=await seedvr_pass(folder,j,cmd,env,f'分区放大 {i+1}/2 · ')
        if rotated:piece=piece.transpose(Image.Transpose.TRANSPOSE)
        piece=piece.resize((x1-x0,height),Image.Resampling.LANCZOS)
        if i:
            mask=Image.new('L',piece.size,255)
            ramp=np.linspace(0,255,first_end-x0,dtype=np.uint8)[None,:]
            mask.paste(Image.fromarray(ramp).resize((first_end-x0,height)),(0,0))
            merged.paste(piece,(x0,0),mask)
        else:merged.paste(piece,(0,0))
    j['stage']='分区重建完成'
    return merged.transpose(Image.Transpose.TRANSPOSE) if rotated else merged

async def seedvr_pass(folder,j,args,env,prefix):
    output=Path(args[args.index('--output')+1])
    logfile=output.with_suffix('.log')
    j['stage']=prefix+'加载 SeedVR2 模型'
    process=await asyncio.create_subprocess_exec(*args,cwd=str(INSTALL/'runtime/SeedVR2-test'),env=env,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW,limit=1024*1024)
    phases={'Phase 1:':'阶段 1/4 · 分块编码图片','Phase 2:':'阶段 2/4 · AI 重建细节','Phase 3:':'阶段 3/4 · 分块解码图片','Phase 4:':'阶段 4/4 · 颜色匹配与保存'}
    try:
        async with asyncio.timeout(1800):
            with logfile.open('w',encoding='utf8') as log:
                while line:=await process.stdout.readline():
                    text=line.decode('utf8',errors='replace');log.write(text);log.flush()
                    for marker,label in phases.items():
                        if marker in text:j['stage']=prefix+label
            code=await process.wait()
        if code or not output.exists():
            if 'out of memory' in logfile.read_text(encoding='utf8').lower():
                raise MemoryError('SeedVR2 重建细节时显存不足。')
            raise RuntimeError(f'SeedVR2 放大失败，详情见任务目录 {logfile.name}。')
        j['stage']='整理输出画幅'
        with Image.open(output) as image:return image.convert('RGB')
    finally:
        if process.returncode is None:
            import psutil
            try:
                for child in psutil.Process(process.pid).children(recursive=True):child.terminate()
                process.terminate()
            except (ProcessLookupError,psutil.NoSuchProcess):pass
            await process.wait()

def upscale_graph(filename, model):
    return {
      '1':{'class_type':'LoadImage','inputs':{'image':filename}},
      '2':{'class_type':'UpscaleModelLoader','inputs':{'model_name':model}},
      '3':{'class_type':'ImageUpscaleWithModel','inputs':{'upscale_model':['2',0],'image':['1',0]}},
      '10':{'class_type':'SaveImage','inputs':{'images':['3',0],'filename_prefix':'WebUI/upscale'}}}

def graph(prompt, size, seed, filename=None):
    g=copy.deepcopy(BASE)
    w,h=size
    g['4']['inputs']['text']=prompt
    for k in ['6','7']: g[k]['inputs'].update(width=w,height=h)
    g['8']['inputs']['seed']=seed
    if filename:
        g['11']={'class_type':'LoadImage','inputs':{'image':filename}}
        g['12']={'class_type':'VAEEncode','inputs':{'pixels':['11',0],'vae':['3',0]}}
        g['13']={'class_type':'ReferenceLatent','inputs':{'conditioning':['4',0],'latent':['12',0]}}
        g['14']={'class_type':'ConditioningZeroOut','inputs':{'conditioning':['4',0]}}
        g['15']={'class_type':'ReferenceLatent','inputs':{'conditioning':['14',0],'latent':['12',0]}}
        g['8']['inputs'].update(model=['1',0],positive=['13',0],negative=['15',0])
    return g

async def track_progress(ws,j,g):
    names={'UNETLoader':'加载生成模型','CLIPLoader':'加载文本模型','CLIPTextEncode':'理解提示词','VAELoader':'加载解码器','VAEEncode':'编码参考图','KSampler':'采样生成','VAEDecodeTiled':'分块解码图片','UpscaleModelLoader':'加载放大模型','ImageUpscaleWithModel':'分块放大','SaveImage':'保存图片'}
    async for msg in ws:
        if msg.type!=WSMsgType.TEXT: continue
        event=json.loads(msg.data);d=event.get('data',{});kind=event.get('type')
        if d.get('prompt_id') and j.get('prompt_id') and d['prompt_id']!=j['prompt_id']:continue
        if kind=='executing' and d.get('node'):
            node=g.get(str(d['node']),{}).get('class_type','')
            j.update(stage=names.get(node,'处理图片'),progress_value=0,progress_max=0)
        elif kind=='progress':
            j.update(progress_value=d.get('value',0),progress_max=d.get('max',0))
        elif kind=='execution_start':j['stage']='开始处理'

async def run_job(jid, prompt, mode, size, seed, original, mask, feather, fit='pad', target=4096, redraw_strength=0.25):
    j=JOBS[jid]
    async with LOCK:
      monitor=None
      try:
        j['status']='正在生成'; start=time.monotonic()
        filename=None
        if original:
            filename=f'webui_{jid}.png'
            if mode=='upscale':
                source=Image.new('RGBA',original.size,'white');source.alpha_composite(original);source=source.convert('RGB')
                if max(source.size)>target: source.thumbnail((target,target),Image.Resampling.LANCZOS)
            else: original.convert('RGB').resize(size,Image.Resampling.LANCZOS).save(COMFY/'input'/filename)
        if mode=='upscale':
            generated=await seedvr_upscale(j,source,seed,fit,target)
        else:
            if mode=='redraw':
                g=graph(prompt,size,seed)
                g['11']={'class_type':'LoadImage','inputs':{'image':filename}}
                g['12']={'class_type':'VAEEncode','inputs':{'pixels':['11',0],'vae':['3',0]}}
                g['8']['inputs'].update(latent_image=['12',0],denoise=redraw_strength)
                j['redraw_strength']=redraw_strength
            else:
                g=graph(prompt,size,seed,filename)
            g['10']['inputs']['filename_prefix']=f'WebUI/{jid}'
            (DATA/jid/'workflow_api.json').write_text(json.dumps(g,ensure_ascii=False,indent=2),encoding='utf8')
            async with ClientSession(trust_env=False) as s:
                ws=await s.ws_connect('http://127.0.0.1:8188/ws',params={'clientId':jid})
                monitor=asyncio.create_task(track_progress(ws,j,g));j['stage']='等待显卡队列'
                async with s.post('http://127.0.0.1:8188/prompt',json={'prompt':g,'client_id':jid}) as r:
                    result=await r.json()
                    if r.status!=200: raise RuntimeError(str(result))
                pid=result['prompt_id']; j['prompt_id']=pid
                while True:
                    await asyncio.sleep(2)
                    async with s.get(f'http://127.0.0.1:8188/history/{pid}') as r: history=await r.json()
                    if pid not in history: continue
                    record=history[pid]
                    if record.get('status',{}).get('status_str')=='error': raise RuntimeError('ComfyUI 生成失败，请查看服务器日志。')
                    img=record['outputs']['10']['images'][0]
                    src=COMFY/'output'/img['subfolder']/img['filename']
                    generated=Image.open(src).convert('RGB'); break
        if mode=='upscale':
            if fit=='crop': final=ImageOps.fit(generated,(target,target),Image.Resampling.LANCZOS)
            else: final=ImageOps.pad(generated,(target,target),Image.Resampling.LANCZOS,color='white')
        elif original:
            if mode=='mask':
                generated=generated.resize(original.size,Image.Resampling.LANCZOS).convert('RGBA')
                support=np.asarray(mask)>0
                if feather:
                    blurred=mask.filter(ImageFilter.GaussianBlur(feather))
                    mask=Image.fromarray(np.where(support,np.asarray(blurred),0).astype('uint8'))
                generated.putalpha(original.getchannel('A'))
                final=Image.composite(generated,original,mask)
                diff=np.any(np.asarray(final)!=np.asarray(original),axis=2)
                j['outside_changed_pixels']=int(np.count_nonzero(diff & ~support))
                j['inside_changed_pixels']=int(np.count_nonzero(diff & support))
                if j['outside_changed_pixels']: raise RuntimeError('蒙版保护校验失败，未交付结果。')
            else: final=generated
        else: final=generated
        final.save(DATA/jid/'result.png')
        j.update(status='完成',seconds=round(time.monotonic()-start,1),result=f'/api/result/{jid}',width=final.width,height=final.height)
      except Exception as e:
        j.update(status='失败',error=str(e)[:1800])
      finally:
        if monitor:
            monitor.cancel()
            await asyncio.gather(monitor,return_exceptions=True)
      (DATA/jid/'status.json').write_text(json.dumps(j,ensure_ascii=False,indent=2),encoding='utf8')

async def submit(request):
    origin=request.headers.get('Origin')
    if origin and origin != f'{request.scheme}://{request.host}': raise web.HTTPForbidden()
    if sum(j['status'] not in ['完成','失败'] for j in JOBS.values())>=5: raise web.HTTPTooManyRequests(text='队列已满，请稍后再试。')
    d=await request.post(); prompt=str(d.get('prompt','')).strip(); mode=d.get('mode','text')
    if (mode not in ('upscale','redraw') and not prompt) or len(prompt)>8000 or mode not in ['text','edit','mask','upscale','redraw']: raise web.HTTPBadRequest(text='请输入有效提示词。')
    try:
        res=int(d.get('resolution','1024')); seed=int(d.get('seed','-1')); feather=int(d.get('feather','4'))
        allowed_sizes=[1024,2048,3072] if mode=='text' else [1024,2048]
        if res not in allowed_sizes or not 0<=feather<=32: raise ValueError()
        if seed<0: seed=secrets.randbelow(2**48)
        if seed>2**53-1: raise ValueError()
        if mode=='upscale': seed%=2**32
        redraw_strength=float(d.get('redraw_strength',0.25)) if mode=='redraw' else 0.25
        if not 0.05<=redraw_strength<=1: raise ValueError('重绘强度范围为 0.05 到 1')
        target=int(d.get('upscale_size',4096)) if mode=='upscale' else 4096
        if target not in (3072,4096): raise ValueError('放大尺寸请选择 3K 或 4K')
        fit=d.get('fit','pad')
        if fit not in ['pad','crop']: raise ValueError('无效的画幅处理方式')
        original=mask=None; size=(res,res)
        if mode!='text':
            original=ImageOps.exif_transpose(Image.open(d['image'].file))
            if original.width*original.height>24_000_000: raise ValueError('图片最多2400万像素')
            original=original.convert('RGBA')
            scale=res/max(original.size); size=tuple(max(64,round(x*scale/16)*16) for x in original.size)
            if mode=='mask':
                mask=Image.open(d['mask'].file).convert('L')
                if mask.size!=original.size: raise ValueError('蒙版和原图尺寸必须相同')
                if not mask.getbbox(): raise ValueError('请先涂抹需要修改的区域')
        else:
            ratio=d.get('ratio','1:1')
            size={'1:1':(res,res),'4:3':(res,res*3//4),'3:4':(res*3//4,res)}[ratio]
    except Exception as e: raise web.HTTPBadRequest(text=f'图片或参数无效：{e}')
    jid=secrets.token_hex(12); (DATA/jid).mkdir()
    if original: original.save(DATA/jid/'original.png')
    if mask: mask.save(DATA/jid/'mask.png')
    JOBS[jid]={'id':jid,'status':'排队中','mode':mode,'seed':seed,'prompt':prompt,'submitted_at':time.time()}
    request.app['tasks'].add(task:=asyncio.create_task(run_job(jid,prompt,mode,size,seed,original,mask,feather,fit,target,redraw_strength)))
    task.add_done_callback(request.app['tasks'].discard)
    return web.json_response(JOBS[jid])

async def status(request):
    j=JOBS.get(request.match_info['id'])
    if not j: raise web.HTTPNotFound()
    result=dict(j)
    if j['status'] not in ['完成','失败']:
        result['elapsed_seconds']=int(time.time()-j.get('submitted_at',time.time()))
        active=[key for key,value in JOBS.items() if value['status'] not in ['完成','失败']]
        result['queue_ahead']=active.index(j['id']) if j['id'] in active else 0
    return web.json_response(result)
async def result(request):
    jid=request.match_info['id']
    if len(jid)!=24 or any(c not in '0123456789abcdef' for c in jid): raise web.HTTPNotFound()
    p=DATA/jid/'result.png'
    if not p.exists(): raise web.HTTPNotFound()
    return web.FileResponse(p)
async def index(request): return web.FileResponse(ROOT/'index.html')
async def main():
    hosts=set(json.loads((ROOT/'hosts.json').read_text(encoding='utf-8-sig'))) if (ROOT/'hosts.json').exists() else {'127.0.0.1'}
    hosts.add('127.0.0.1')
    @web.middleware
    async def guard(request,handler):
        if request.host not in {f'{h}:8189' for h in hosts} | {'localhost:8189'}: raise web.HTTPForbidden()
        return await handler(request)
    app=web.Application(client_max_size=64*1024**2,middlewares=[guard]); app['tasks']=set()
    app.add_routes([web.get('/',index),web.post('/api/jobs',submit),web.get('/api/jobs/{id}',status),web.get('/api/result/{id}',result)])
    runner=web.AppRunner(app); await runner.setup()
    for host in hosts:
        await web.TCPSite(runner,host,8189).start(); print(f'WebUI http://{host}:8189',flush=True)
    await asyncio.Event().wait()
if __name__=='__main__': asyncio.run(main())
