$ErrorActionPreference = 'Stop'
$project = Split-Path $PSScriptRoot -Parent
$root = Join-Path $project 'runtime'
$env:HF_HOME = "$root\cache\huggingface"
$env:TORCH_HOME = "$root\cache\torch"
$env:TEMP = "$root\tmp"
$env:TMP = "$root\tmp"
$lan = @(Get-NetAdapter -Physical | Where-Object Status -eq Up | ForEach-Object {
    Get-NetIPAddress -InterfaceIndex $_.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notlike '169.254.*' } | Select-Object -ExpandProperty IPAddress
})
$hostsList = @('127.0.0.1') + $lan
ConvertTo-Json -InputObject $hostsList | Set-Content "$PSScriptRoot\hosts.json" -Encoding UTF8
function Test-Port([int]$port) {
    $client = New-Object System.Net.Sockets.TcpClient
    try { $client.Connect('127.0.0.1',$port); return $true } catch { return $false } finally { $client.Dispose() }
}
if (-not (Test-Port 8188)) {
    Start-Process -FilePath "$root\venv\Scripts\python.exe" -ArgumentList 'main.py --listen 127.0.0.1 --port 8188 --reserve-vram 2 --disable-dynamic-vram' -WorkingDirectory "$root\ComfyUI-source" -WindowStyle Hidden -RedirectStandardOutput "$PSScriptRoot\comfy-out.log" -RedirectStandardError "$PSScriptRoot\comfy-error.log"
}
for ($i=0; $i -lt 180 -and -not (Test-Port 8188); $i++) { Start-Sleep -Seconds 1 }
if (-not (Test-Port 8188)) { throw 'ComfyUI failed to start. See E:\AI\WebUI\comfy-error.log' }
if (-not (Test-Port 8189)) {
    Start-Process -FilePath "$root\venv\Scripts\python.exe" -ArgumentList ('"'+$PSScriptRoot+'\server.py"') -WorkingDirectory "$PSScriptRoot" -WindowStyle Hidden -RedirectStandardOutput "$PSScriptRoot\server.log" -RedirectStandardError "$PSScriptRoot\error.log"
}
for ($i=0; $i -lt 20 -and -not (Test-Port 8189); $i++) { Start-Sleep -Seconds 1 }
if (-not (Test-Port 8189)) { throw 'WebUI failed to start. See E:\AI\WebUI\error.log' }
@('Local: http://127.0.0.1:8189') + @($lan | ForEach-Object { "LAN: http://${_}:8189" }) | Set-Content "$PSScriptRoot\ACCESS.txt"
Start-Process 'http://127.0.0.1:8189'
